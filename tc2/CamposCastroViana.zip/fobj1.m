function [f] = fobj1(x, custo_manutencao)
f = custo_manutencao(x);
end

