clear all
close all
clc
%=========================================================================
CSVInput = 'CamposCastroViana.csv';
%=========================================================================

[HVI] = EvalParetoApp(CSVInput);